function fungsi1(){
  var a = document.getElementById("isitrn");
  if(a.style.display==="none")
  {
      a.style.display = 'block';
  }
  else{
      a.style.display = 'none';
  }
}

function fungsi2(){
    var a = document.getElementById("isitrn2");
    if(a.style.display==="none")
    {
        a.style.display = 'block';
    }
    else{
        a.style.display = 'none';
    }
  }

  function fungsi3(){
    var a = document.getElementById("isitrn3");
    if(a.style.display==="none")
    {
        a.style.display = 'block';
    }
    else{
        a.style.display = 'none';
    }
  }